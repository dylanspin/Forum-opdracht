<?php
include "autoload.php";
//include "include1.php";
 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Begin</title>
  </head>
  <body>


  </body>
</html>
